package com.company.store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineFashionStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineFashionStoreApplication.class, args);
	}

}
